
console.log('[CPALEAD] - Links');

document.querySelectorAll('a').forEach(a => {
    a.classList.add('ad');
    console.log('[CPALEAD] - added class', a);
});

