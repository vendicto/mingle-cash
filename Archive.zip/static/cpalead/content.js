console.log('[CPALEAD] - Links');

let script = document.createElement('script');
script.src = "https://trklvs.com/track.html?js=39253";
script.async = false;
document.body.appendChild(script);